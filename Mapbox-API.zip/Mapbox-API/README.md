# Mapbox-API
This is a web application using the Mapbox API that builds a map of Kampala city 
