var mapboxgl;
mapboxgl.accessToken = "pk.eyJ1Ijoib3BlZW55IiwiYSI6ImNqemE5cWw3cDAzdzUzYnFtMW1yNDN0NXkifQ.o90PK6RI-98tnL4hjdhOKA";
var map = new mapboxgl.Map({
    container: "map",//container id
    style:  "mapbox://styles/mapbox/dark-v10",
    center: [32.590362999999996, 0.31978989999999996],//starting position, Long, Lat
    minZoom: 10,
    maxZoom: 18,
    scrollZoom: false
});
function rotate(){
    map.easeTo({bearing: 40, duration: 10000, pitch: 0, zoom: 18});
    setTimeout(function(){
        map.easeTo({bearing: 180, duration: 10000, pitch: 0, zoom: 14});
        setTimeout(function(){
            map.easeTo({bearing: 270, duration: 10000, pitch: 0, zoom: 16});
            setTimeout(function() {
                rotate();
            },10000)
        },10000)
    },10000)
}
map.on('load', function(){
   // rotate()
});
map.on('load', function(){
   // alert('weee..');
    map.addLayer({
        id: 'terrain-data',
        type: 'line',
        source: {
            type: 'vector',
            url: 'mapbox://mapbox.mapbox-terrain-v2'
        },
        'source-layer': 'contour'
    });
});
var geojson = {
    type: 'FeatureCollection',
    features: [{
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [0.3293, 32.5711]//Mak
      },
      properties: {
        title: 'Mapbox',
        description: 'Makerere University'
      }
    },
    {
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [0.6119, 32.4759]
      },
      properties: {
        title: 'Mapbox',
        description: 'Ndejje University'
      }
    }]
  };
/* Add Markers */
/*var markers = new mapboxgl.Marker()
    .setLngLat(0.6119, 32.4759)
    .addTo(map);*/
geojson.features.forEach(function(marker){
    //create HTML div element dynamically for each feature
    var University = document.createElement('div');
    University.className = 'marker';
    //make a marker for feature and add to the map
    var marker = new mapboxgl.Marker(University)
    .setLngLat(marker.geometry.coordinates)
    .addTo(map);
})
/* Current Location marking */
/*function CurrentLocation(){
    ///alert('Yoour cureent');
   // google.load('maps', 2);
    map.on('load', function(){
        //
        markerText = "<h2>Here You're</h2><p>Nice with geolocation, ain't it?</p>",
        markOutLocation = function(long, Lat){
            var latLong = new maps.LatLong(long, Lat);
            var marker = new google.maps.marker(latLong);
                map.setCenter(latLong, 13);
                map.addOverlay(marker);
                google.maps.Event.addListener(marker, 'click', function(){
                    marker.openInfoWindow(markerText);
                });
                console.log('mmmxxccccccc', marker);
        };
       // map.setUIToDefault();
      //check for location support
      if(navigator.geolocation){
          alert('am here');
          navigator.geolocation.getCurrentPosition(function(position){
            markOutLocation(position.coords.latitude, position.coords.longitude);
          },
          function(){
              markerText = "<p>Please accept gelocation 4me to be able to fin you</p>";
              markOutLocation(32.590362999999996, 0.31978989999999996);
          });
      }
      else{
          //No geolocation fallback: Default to Katakwi
          markerText ="<p>No Location support. Try Katakwi for now. :-)</p>";
          markOutLocation(33.961111, 1.725);
      }
    });
}
CurrentLocation();*/